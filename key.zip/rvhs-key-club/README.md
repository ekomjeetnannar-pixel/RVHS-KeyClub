# River Valley High School Key Club

Filler/placeholder website for the RVHS Key Club.

## Structure

```
index.html      main page
css/style.css   all styling
```

## Publishing with GitHub Pages

1. Create a new repository on GitHub and upload these files, keeping the folder structure intact (`index.html` at the root, `css/style.css` inside a `css` folder).
2. Go to **Settings → Pages** in the repo.
3. Under "Build and deployment," set the source to **Deploy from a branch**, branch `main`, folder `/root`.
4. GitHub will give you a `https://<username>.github.io/<repo>/` URL once it's live.

## Using a custom domain (RVHSKeyClub.com)

1. In the same **Settings → Pages** screen, enter `RVHSKeyClub.com` under "Custom domain."
2. At your domain registrar, add the DNS records GitHub's Pages docs specify (an `A` record pointing at GitHub's IPs, or a `CNAME` record if using a subdomain).
3. Wait for DNS to propagate (can take up to 24 hours), then GitHub will auto-issue an HTTPS certificate for the domain.
